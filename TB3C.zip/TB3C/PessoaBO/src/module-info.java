/**
 * 
 */
/**
 * 
 */
module unioeste.geral.pessoa {
	exports unioeste.geral.pessoa.bo.cpf;
	exports unioeste.geral.pessoa.bo.ddd;
	exports unioeste.geral.pessoa.bo.ddi;
	exports unioeste.geral.pessoa.bo.email;
	exports unioeste.geral.pessoa.bo.pessoa;
	exports unioeste.geral.pessoa.bo.pessoaFisica;
	exports unioeste.geral.pessoa.bo.telefone;
	requires enderecosBO;
}
