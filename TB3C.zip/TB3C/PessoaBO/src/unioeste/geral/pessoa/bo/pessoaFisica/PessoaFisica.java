package unioeste.geral.pessoa.bo.pessoaFisica;

import unioeste.geral.endereco.bo.enderecoespecifico.EnderecoEspecifico;
import unioeste.geral.pessoa.bo.telefone.Telefone;
import unioeste.geral.pessoa.bo.cpf.Cpf;
import unioeste.geral.pessoa.bo.email.Email;
import unioeste.geral.pessoa.bo.pessoa.Pessoa;

import java.io.Serializable;
import java.util.List;

public class PessoaFisica extends Pessoa implements Serializable {

    private static final long serialVersionUID = 1L;
	private String primeiroNome;
    private String nomeMeio;
    private String ultimoNome;
    private Cpf cpf;
    
    public PessoaFisica() {
    	super();
    }
    
    
    public PessoaFisica(Long id, String nome, EnderecoEspecifico enderecoEspecifico, List<Telefone> telefones, List<Email> emails, String primeiroNome, String nomeMeio, String ultimoNome, Cpf cpf) {
        super(id, nome, enderecoEspecifico, telefones, emails);
        this.primeiroNome = primeiroNome;
        this.nomeMeio = nomeMeio;
        this.ultimoNome = ultimoNome;
        this.cpf = cpf;
    }

    public String getPrimeiroNome() {
        return primeiroNome;
    }

    public void setPrimeiroNome(String primeiroNome) {
        this.primeiroNome = primeiroNome;
    }

    public String getNomeMeio() {
        return nomeMeio;
    }

    public void setNomeMeio(String nomeMeio) {
        this.nomeMeio = nomeMeio;
    }

    public String getUltimoNome() {
        return ultimoNome;
    }

    public void setUltimoNome(String ultimoNome) {
        this.ultimoNome = ultimoNome;
    }

    public Cpf getCpf() {
        return cpf;
    }

    public void setCpf(Cpf cpf) {
        this.cpf = cpf;
    }
}