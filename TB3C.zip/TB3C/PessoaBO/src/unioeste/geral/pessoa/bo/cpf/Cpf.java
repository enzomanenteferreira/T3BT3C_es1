package unioeste.geral.pessoa.bo.cpf;

import java.io.Serializable;

public class Cpf implements Serializable {

    private static final long serialVersionUID = 1L;
	private String cpf;

    public Cpf(String cpf) {
        this.cpf = cpf;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }


}