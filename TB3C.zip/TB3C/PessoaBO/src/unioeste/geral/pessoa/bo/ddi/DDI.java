package unioeste.geral.pessoa.bo.ddi;

import java.io.Serializable;

public class DDI implements Serializable {

    private static final long serialVersionUID = 1L;
	private Integer numeroDDI;

    public DDI(Integer numeroDDI) {
        this.numeroDDI = numeroDDI;
    }

    public Integer getNumeroDDI() {
        return numeroDDI;
    }

    public void setNumeroDDI(Integer numeroDDI) {
        this.numeroDDI = numeroDDI;
    }
}