/**
 * 
 */
/**
 * 
 */
module receitamedicaBO {
	requires enderecosBO;
	requires unioeste.geral.pessoa;
	exports unioeste.geral.receitaMedica.bo.cid;
	exports unioeste.geral.receitaMedica.bo.crm;
	exports unioeste.geral.receitaMedica.bo.medicamento;
	exports unioeste.geral.receitaMedica.bo.medicamentoprescrito;
	exports unioeste.geral.receitaMedica.bo.medico;
	exports unioeste.geral.receitaMedica.bo.paciente;
	exports unioeste.geral.receitaMedica.bo.receitaMedica;
}