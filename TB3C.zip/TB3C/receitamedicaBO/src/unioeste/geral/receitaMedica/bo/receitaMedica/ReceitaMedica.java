package unioeste.geral.receitaMedica.bo.receitaMedica;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

import unioeste.geral.receitaMedica.bo.cid.Cid;
import unioeste.geral.receitaMedica.bo.medicamentoprescrito.MedicamentoPrescrito;
import unioeste.geral.receitaMedica.bo.medico.Medico;
import unioeste.geral.receitaMedica.bo.paciente.Paciente;

public class ReceitaMedica implements Serializable{
    private Long id;

    private Integer numero;
    private LocalDate dataEmissao;
    private Medico medico;
    private Paciente paciente;

    private Cid Cid;

    private List<MedicamentoPrescrito> MedicamentoPrescrito;

    public ReceitaMedica() {

    }
    

    public ReceitaMedica(Long id, Integer numero, LocalDate dataEmissao, Medico medico, Paciente paciente, Cid Cid, List<MedicamentoPrescrito> MedicamentoPrescrito) {
        this.id = id;
        this.numero = numero;
        this.dataEmissao = dataEmissao;
        this.medico = medico;
        this.paciente = paciente;
        this.Cid = Cid;
        this.MedicamentoPrescrito = MedicamentoPrescrito;
    }
}
