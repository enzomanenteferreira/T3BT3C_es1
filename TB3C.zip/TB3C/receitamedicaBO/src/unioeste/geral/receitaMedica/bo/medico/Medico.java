package unioeste.geral.receitaMedica.bo.medico;

import java.io.Serializable;
import java.util.List;

import unioeste.geral.endereco.bo.enderecoespecifico.EnderecoEspecifico;
import unioeste.geral.pessoa.bo.cpf.Cpf;
import unioeste.geral.pessoa.bo.email.Email;
import unioeste.geral.pessoa.bo.pessoaFisica.PessoaFisica;
import unioeste.geral.pessoa.bo.telefone.Telefone;
import unioeste.geral.receitaMedica.bo.crm.CRM;

public class Medico extends PessoaFisica implements Serializable {

    private static final long serialVersionUID = 1L;
	private CRM crm;


    public Medico(Long id, String nome, EnderecoEspecifico enderecoEspecifico, List<Telefone> telefones, List<Email> emails, String primeiroNome, String nomeMeio, String ultimoNome, Cpf cpf, CRM crm) {
        super(id, nome, enderecoEspecifico, telefones, emails, primeiroNome, nomeMeio, ultimoNome, cpf);
        this.crm = crm;
    }

    public CRM getCrm() {
        return crm;
    }

    public void setCrm(CRM crm) {
        this.crm = crm;
    }
}