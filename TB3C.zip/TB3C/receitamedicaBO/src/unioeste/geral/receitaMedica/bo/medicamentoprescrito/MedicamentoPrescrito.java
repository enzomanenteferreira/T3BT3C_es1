package unioeste.geral.receitaMedica.bo.medicamentoprescrito;


import java.io.Serializable;
import java.time.LocalDate;

import unioeste.geral.receitaMedica.bo.medicamento.Medicamento;

public class MedicamentoPrescrito implements Serializable {

    private static final long serialVersionUID = 1L;
	private Long id;
    private LocalDate dataInicio;
    private LocalDate dataFim;
    private String posologia;
    private Medicamento medicamento;

    public MedicamentoPrescrito() {
    }

    public MedicamentoPrescrito(Long id, LocalDate dataInicio, LocalDate dataFim, String posologia, Medicamento medicamento) {
        this.id = id;
        this.dataInicio = dataInicio;
        this.dataFim = dataFim;
        this.posologia = posologia;
        this.medicamento = medicamento;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDate getDataInicio() {
        return dataInicio;
    }

    public void setDataInicio(LocalDate dataInicio) {
        this.dataInicio = dataInicio;
    }

    public LocalDate getDataFim() {
        return dataFim;
    }

    public void setDataFim(LocalDate dataFim) {
        this.dataFim = dataFim;
    }

    public String getPosologia() {
        return posologia;
    }

    public void setPosologia(String posologia) {
        this.posologia = posologia;
    }

    public Medicamento getMedicamento() {
        return medicamento;
    }

    public void setMedicamento(Medicamento medicamento) {
        this.medicamento = medicamento;
    }
}