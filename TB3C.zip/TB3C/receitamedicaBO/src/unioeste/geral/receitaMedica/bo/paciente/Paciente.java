package unioeste.geral.receitaMedica.bo.paciente;

import java.io.Serializable;

import unioeste.geral.endereco.bo.enderecoespecifico.EnderecoEspecifico;
import unioeste.geral.pessoa.bo.cpf.Cpf;
import unioeste.geral.pessoa.bo.email.Email;
import unioeste.geral.pessoa.bo.pessoaFisica.PessoaFisica;
import unioeste.geral.pessoa.bo.telefone.Telefone;

import java.io.Serializable;
import java.util.List;

public class Paciente extends PessoaFisica implements Serializable {

    private static final long serialVersionUID = 1L;

    	public Paciente() {
    		super();
    	}

    public Paciente(Long id, String nome, EnderecoEspecifico enderecoEspecifico,
            List<Telefone> telefones, List<Email> emails,
            String primeiroNome, String nomeMeio, String ultimoNome, Cpf cpf) {
    		super(id, nome, enderecoEspecifico, telefones, emails, primeiroNome, nomeMeio, ultimoNome, cpf);
}


}