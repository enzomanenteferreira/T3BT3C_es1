package unioeste.geral.endereco.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import unioeste.geral.endereco.bo.logradouro.Logradouro;

public class LogradouroDAO {
	@SuppressWarnings("exports")
	public static Logradouro selectLogradouro(int id, Connection conexao) throws Exception{
		String sql = "SELECT logradouro.nome_logradouro, logradouro.id_tipo_logradouro FROM logradouro WHERE logradouro.id_logradouro = ?";
		PreparedStatement cmd = conexao.prepareStatement(sql.toString());
		cmd.setLong(1, id);
		ResultSet result = cmd.executeQuery();
		

		if(result.next()) {
			Logradouro logradouro = new Logradouro();
			
			logradouro.setNome(result.getString("nome_logradouro"));
			logradouro.setId(id);
			logradouro.setTipo_logradouro(TipoLogradouroDAO.selectTipoLogradouro(result.getInt("id_tipo_logradouro"), conexao));
			
			return logradouro;
		}
		
		return null;

	}
	
	@SuppressWarnings("exports")
	public static List<Logradouro> listarTodosLogradouros(@SuppressWarnings("exports") Connection conexao) throws Exception {
        String sql = "SELECT * FROM logradouro";
        PreparedStatement cmd = conexao.prepareStatement(sql);
        ResultSet result = cmd.executeQuery();

        List<Logradouro> listaLogradouros = new ArrayList<>();

        while (result.next()) {
            Logradouro logradouro = new Logradouro();
            logradouro.setId(result.getInt("id_logradouro"));
            logradouro.setNome(result.getString("nome_logradouro"));
            // Buscando o tipo de logradouro
            logradouro.setTipo_logradouro(TipoLogradouroDAO.selectTipoLogradouro(result.getInt("id_tipo_logradouro"), conexao));
            
            listaLogradouros.add(logradouro);
        }

        return listaLogradouros;
    }
}