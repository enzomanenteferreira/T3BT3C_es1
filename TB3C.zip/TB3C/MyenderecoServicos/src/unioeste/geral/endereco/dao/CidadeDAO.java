package unioeste.geral.endereco.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import unioeste.apoio.banco.ConexaoBanco;
import unioeste.geral.endereco.bo.cidade.Cidade;

public class CidadeDAO {
	public static Cidade selectCidade(int id, Connection conexao) throws Exception{
		StringBuffer sql = new StringBuffer("SELECT cidade.nome_cidade, cidade.sigla_estado ");
		sql.append("FROM cidade WHERE cidade.id_cidade = ?;");
		PreparedStatement cmd = conexao.prepareStatement(sql.toString());
		cmd.setInt(1, id);
		ResultSet result = cmd.executeQuery();
		
		if(result.next()) {
			Cidade cidade = new Cidade();
			
			cidade.setId(id);
			cidade.setNome(result.getString("nome_cidade"));
			cidade.setEstado(UFDAO.selectEstado(result.getString("sigla_estado"), conexao));
			
			return cidade;
		}
		
		return null;

	}
	
    // Novo método para listar todas as cidades
    @SuppressWarnings("exports")
	public static List<Cidade> listarTodasCidades(Connection conexao) throws Exception {
        StringBuffer sql = new StringBuffer("SELECT * FROM cidade;");
        PreparedStatement cmd = conexao.prepareStatement(sql.toString());
        ResultSet result = cmd.executeQuery();

        List<Cidade> listaCidades = new ArrayList<>();

        while (result.next()) {
            Cidade cidade = new Cidade();
            cidade.setId(result.getInt("id_cidade"));
            cidade.setNome(result.getString("nome_cidade"));
            // Aqui chamamos novamente o UFDAO para buscar informações do estado
            cidade.setEstado(UFDAO.selectEstado(result.getString("sigla_estado"), conexao));

            listaCidades.add(cidade);
        }

        return listaCidades;
    }
}
