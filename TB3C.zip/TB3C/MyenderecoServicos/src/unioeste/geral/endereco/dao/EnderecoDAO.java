package unioeste.geral.endereco.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import unioeste.apoio.banco.ConexaoBanco;
import unioeste.geral.endereco.bo.endereco.Endereco;

public class EnderecoDAO {

	public static Endereco selectEnderecoId (int id, Connection conexao) throws Exception {

		StringBuffer sql = new StringBuffer("SELECT endereco.cep, endereco.id_cidade, ");
		sql.append("endereco.id_bairro, endereco.id_logradouro FROM endereco ");
		sql.append("WHERE endereco.id_endereco = ?;");
		PreparedStatement cmd = conexao.prepareStatement(sql.toString());
		cmd.setInt(1, id);
		ResultSet result = cmd.executeQuery();
		
		if(result.next()) {
			Endereco endereco = new Endereco();
			endereco.setId(id);
			endereco.setCidade(CidadeDAO.selectCidade(result.getInt("id_cidade"), conexao));
			endereco.setBairro(BairroDAO.selectBairro(result.getInt("id_bairro"), conexao));
			endereco.setLogradouro(LogradouroDAO.selectLogradouro(result.getInt("id_logradouro"), conexao));
			endereco.setCEP(result.getString("cep"));
			
			return endereco;
		}
		
		return null;
	}
	
	public static Endereco selectEnderecoCEP (String cep, Connection conexao) throws Exception {
		
	    StringBuffer sql = new StringBuffer("SELECT endereco.id_endereco, endereco.cep, endereco.id_cidade, ");
	    sql.append("endereco.id_bairro, endereco.id_logradouro FROM endereco ");
	    sql.append("WHERE endereco.cep = ?;");
	    PreparedStatement cmd = conexao.prepareStatement(sql.toString());
	    cmd.setString(1, cep);
	    ResultSet result = cmd.executeQuery();
	    
	    if(result.next()) {
	        Endereco endereco = new Endereco();
	        endereco.setId(result.getInt("id_endereco"));
	        endereco.setCidade(CidadeDAO.selectCidade(result.getInt("id_cidade"), conexao));
	        endereco.setBairro(BairroDAO.selectBairro(result.getInt("id_bairro"), conexao));
	        endereco.setLogradouro(LogradouroDAO.selectLogradouro(result.getInt("id_logradouro"), conexao));
	        endereco.setCEP(result.getString("cep"));
	        
	        return endereco;
	    }
	    
	    return null;
	}
	
	public static void insertEndereco (Endereco endereco, Connection conexao) throws Exception {
		
		StringBuffer sql = new StringBuffer("INSERT INTO endereco (cep, sigla_estado, id_cidade, id_bairro, id_logradouro) VALUES");
		sql.append("(?, ?, ?, ?, ?);");
		PreparedStatement cmd = conexao.prepareStatement(sql.toString());
		cmd.setString(1, endereco.getCEP());
		cmd.setString(2, endereco.getCidade().getEstado().getSigla());
		cmd.setInt(3, endereco.getCidade().getId());
		cmd.setInt(4, endereco.getBairro().getId());
		cmd.setInt(5, endereco.getLogradouro().getId());
		cmd.executeUpdate();
		
	}
}
