package unioeste.geral.endereco.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import unioeste.apoio.banco.ConexaoBanco;
import unioeste.geral.endereco.bo.bairro.Bairro;

public class BairroDAO {
	
	public static Bairro selectBairro(int id, Connection conexao) throws Exception{
		StringBuffer sql = new StringBuffer("SELECT bairro.nome_bairro ");
		sql.append("FROM bairro WHERE bairro.id_bairro = ?;");
		PreparedStatement cmd = conexao.prepareStatement(sql.toString());
		cmd.setInt(1, id);
		ResultSet result = cmd.executeQuery();
		
		if(result.next()) {
			Bairro bairro = new Bairro();
			
			bairro.setNome(result.getString("nome_bairro"));
			bairro.setId(id);
			
			return bairro;
		}
		
		return null;

	}
	
    // Novo método para listar todos os bairros
    @SuppressWarnings("exports")
	public static List<Bairro> listarTodosBairros(Connection conexao) throws Exception {
        StringBuffer sql = new StringBuffer("SELECT * FROM bairro;");
        PreparedStatement cmd = conexao.prepareStatement(sql.toString());
        ResultSet result = cmd.executeQuery();

        List<Bairro> listaBairros = new ArrayList<>();

        while (result.next()) {
            Bairro bairro = new Bairro();
            bairro.setId(result.getInt("id_bairro"));
            bairro.setNome(result.getString("nome_bairro"));

            listaBairros.add(bairro);
        }

        return listaBairros;
    }
}