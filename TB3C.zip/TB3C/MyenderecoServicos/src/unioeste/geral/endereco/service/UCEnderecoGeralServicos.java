package unioeste.geral.endereco.service;


import unioeste.geral.endereco.bo.cidade.Cidade;
import unioeste.geral.endereco.bo.endereco.Endereco;
import unioeste.geral.endereco.col.CidadeCOL;
import unioeste.geral.endereco.col.EnderecoCOL;
import unioeste.geral.endereco.dao.*;
import unioeste.geral.endereco.infra.CepAPI;
import unioeste.geral.endereco.exception.Exceptions;
import unioeste.apoio.banco.ConexaoBanco;

import java.sql.Connection;


public class UCEnderecoGeralServicos {

    @SuppressWarnings("exports")
	public static Endereco obterEnderecoExterno(String CEP) throws Exception {
        if (!EnderecoCOL.CEPValido(CEP)) {
            throw new Exceptions("Formato de CEP inválido (" + CEP + ")");
        }
        
        Endereco endereco = CepAPI.getCEP(CEP);
        
        if (endereco == null) {
            throw new Exceptions("CEP inexistente (" + CEP + ")");
        }
        
        return endereco;
    }
    
    @SuppressWarnings("exports")
	public static Cidade obterCidade(int id) throws Exception {
        if (!CidadeCOL.idValido(id)) {
            throw new Exceptions("ID da cidade inválido (" + id + ")");
        }
        ConexaoBanco conexao = new ConexaoBanco();
        Connection connection = conexao.createConnection();
        
        Cidade cidade = CidadeDAO.selectCidade(id, connection);
        
        if (cidade == null) {
            throw new Exceptions("Cidade não cadastrada");
        }
        
        conexao.closeConnection(connection);
        
        return cidade;
    }
    
    public static Endereco obterEnderecoPorCEP(String cep) throws Exception {
        if (!EnderecoCOL.CEPValido(cep)) {
            throw new Exceptions("Formato de CEP inválido (" + cep + ")");
        }
        ConexaoBanco conexao = new ConexaoBanco();
        Connection connection = conexao.createConnection();
        
        Endereco endereco = EnderecoDAO.selectEnderecoCEP(cep, connection);
        
        if (endereco == null) {
            throw new Exceptions("Endereço não cadastrado");
        }
        
        conexao.closeConnection(connection);
        
        return endereco;
    }
    
    @SuppressWarnings("exports")
	public static Endereco obterEnderecoPorID(int id) throws Exception {
    	System.out.println("entrou na funcao");
        if (!EnderecoCOL.idValido(id)) {
            throw new Exceptions("Id do endereço inválido (" + id + ")");
        }
        ConexaoBanco conexao = new ConexaoBanco();
        System.out.println("debugg");
        Connection connection = conexao.createConnection();
        
        Endereco endereco = EnderecoDAO.selectEnderecoId(id, connection);
        
        if (endereco == null) {
            throw new Exceptions("Endereço não cadastrado");
        }
        
        conexao.closeConnection(connection);
        
        return endereco;
    }
    
    public static void cadastrarEndereco(@SuppressWarnings("exports") Endereco endereco) throws Exception {
        ConexaoBanco conexao = new ConexaoBanco();
        Connection connection = conexao.createConnection();
        
        if (!EnderecoCOL.EnderecoValido(endereco, connection)) {
            throw new Exceptions("Endereço inválido");
        }
        if (EnderecoCOL.EnderecoCadastrado(endereco, connection)) {
            throw new Exceptions("CEP já cadastrado");
        }
        
        connection.setAutoCommit(false);
        
        EnderecoDAO.insertEndereco(endereco, connection);
        
        connection.commit();
        conexao.closeConnection(connection);
        
        System.out.println("Endereço cadastrado");
    }
}
