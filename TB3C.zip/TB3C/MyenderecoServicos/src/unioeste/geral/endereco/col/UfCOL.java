package unioeste.geral.endereco.col;

import java.sql.Connection;

import unioeste.geral.endereco.bo.uf.Uf;
import unioeste.geral.endereco.dao.UFDAO;

public class UfCOL {
	public static boolean siglaValida(String sigla) {
		return sigla.matches("[A-Z]+") && sigla.length()==2;
	}
	
	public static boolean estadoValido(Uf estado) {
		if(estado==null) return false;
		if(!siglaValida(estado.getSigla())) return false;
		if(estado.getNome()==null) return false;
		
		return true;
	}
	
	public static boolean estadoCadastrado(Uf estado, Connection conexao) throws Exception {
		Uf aux = UFDAO.selectEstado(estado.getSigla(), conexao);
		if(aux==null) return false;
		return true;
	}
}
