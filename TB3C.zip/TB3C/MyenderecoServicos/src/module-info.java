/**
 * 
 */
/**
 * 
 */
module MyenderecoServicos {
	exports unioeste.geral.endereco.col;
	exports unioeste.geral.endereco.dao;
	exports unioeste.geral.endereco.exception;
	exports unioeste.geral.endereco.infra;
	exports unioeste.geral.endereco.service;
	requires MyinfraAPI;
	requires java.sql;
	requires enderecosBO;
	requires org.json;
}