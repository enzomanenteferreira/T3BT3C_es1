package unioeste.geral.endereco.bo.logradouro;

import java.io.Serializable;

import unioeste.geral.endereco.bo.tipologradouro.TipoLogradouro;

public class Logradouro implements Serializable{

    private static final long serialVersionUID = 1L;
	private int id;
    private String nome;
    private TipoLogradouro tipo_logradouro;

    public Logradouro() {
    }

    public Logradouro(int id, String nome, TipoLogradouro tipo_logradouro) {
        this.id = id;
        this.nome = nome;
        this.tipo_logradouro = tipo_logradouro;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public TipoLogradouro getTipo_logradouro() {
        return tipo_logradouro;
    }

    public void setTipo_logradouro(TipoLogradouro tipo_logradouro) {
        this.tipo_logradouro = tipo_logradouro;
    }
}
