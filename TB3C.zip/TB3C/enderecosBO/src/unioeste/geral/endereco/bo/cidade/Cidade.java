package unioeste.geral.endereco.bo.cidade;

import java.io.Serializable;

import unioeste.geral.endereco.bo.uf.Uf;

public class Cidade implements Serializable{

    private static final long serialVersionUID = 1L;
	private int id;
    private String nome;
    private Uf estado;  

    public Cidade() {
    }

    public Cidade(int id, String nome, Uf estado) {
        this.id = id;
        this.nome = nome;
        this.estado = estado;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Uf getEstado() {
        return estado;
    }

    public void setEstado(Uf estado) {
        this.estado = estado;
    }
}
