package unioeste.geral.endereco.bo.endereco;

import java.io.Serializable;

import unioeste.geral.endereco.bo.bairro.Bairro;
import unioeste.geral.endereco.bo.cidade.Cidade;
import unioeste.geral.endereco.bo.logradouro.Logradouro;

public class Endereco implements Serializable{

    private static final long serialVersionUID = 1L;
	private int id;
    private String CEP;
    private Cidade cidade;
    private Bairro bairro;
    private Logradouro logradouro;

    public Endereco() {
    }

    public Endereco(int id, String CEP, Cidade cidade, Bairro bairro, Logradouro logradouro) {
        this.id = id;
        this.CEP = CEP;
        this.cidade = cidade;
        this.bairro = bairro;
        this.logradouro = logradouro;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCEP() {
        return CEP;
    }

    public void setCEP(String cEP) {
        CEP = cEP;
    }

    public Cidade getCidade() {
        return cidade;
    }

    public void setCidade(Cidade cidade) {
        this.cidade = cidade;
    }

    public Bairro getBairro() {
        return bairro;
    }

    public void setBairro(Bairro bairro) {
        this.bairro = bairro;
    }

    public Logradouro getLogradouro() {
        return logradouro;
    }

    public void setLogradouro(Logradouro logradouro) {
        this.logradouro = logradouro;
    }
}
