/**
 * 
 */
/**
 * 
 */
module enderecosBO {
	exports unioeste.geral.endereco.bo.bairro;
	exports unioeste.geral.endereco.bo.cidade;
	exports unioeste.geral.endereco.bo.endereco;
	exports unioeste.geral.endereco.bo.enderecoespecifico;
	exports unioeste.geral.endereco.bo.logradouro;
	exports unioeste.geral.endereco.bo.tipologradouro;
	exports unioeste.geral.endereco.bo.uf;
}