/**
 * 
 */
/**
 * 
 */
module ReceitaMedicaServicos {
	requires receitamedicaBO;
	requires unioeste.geral.pessoa;
	requires java.sql;
	requires enderecosBO;
	requires MyinfraAPI;
	requires MyenderecoServicos;
}