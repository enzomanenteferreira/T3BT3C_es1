package unioeste.geral.receitamedica.col;

import java.sql.Connection;
import unioeste.geral.receitaMedica.bo.paciente.Paciente;
import unioeste.geral.receitamedica.dao.pacienteDAO;

public class pacienteCOL {

    public static boolean idValido(Long id) {
        return id != null && id > 0;
    }

    public static boolean pacienteValido(Paciente paciente) {
        if (paciente == null) {
            return false;
        }
        
        // Validação do nome
        if (paciente.getNome() == null || paciente.getNome().trim().isEmpty()) {
            return false;
        }
        
        // Validação do Endereço Específico
        if (paciente.getEnderecoEspecifico() == null) {
            return false;
        }
        // Como 'numero' é Integer, não usamos trim(). 
        // Você pode validar se é nulo ou se é um número válido (ex: maior que zero)
        if (paciente.getEnderecoEspecifico().getNumero() == null ||
            paciente.getEnderecoEspecifico().getNumero() <= 0) {
            return false;
        }

        // Validação dos telefones (verifica se a lista não é nula e contém pelo menos um telefone)
        if (paciente.getTelefones() == null || paciente.getTelefones().isEmpty()) {
            return false;
        }
        
        // Validação dos emails (verifica se a lista não é nula e contém pelo menos um email)
        if (paciente.getEmails() == null || paciente.getEmails().isEmpty()) {
            return false;
        }
        
        // Validação do CPF
        if (paciente.getCpf() == null ||
            paciente.getCpf().getCpf() == null ||
            paciente.getCpf().getCpf().trim().isEmpty()) {
            return false;
        }
        
        return true;
    }

    public static boolean pacienteExiste(Paciente paciente, Connection conexao) throws Exception {
        if (paciente == null ||
            paciente.getCpf() == null ||
            paciente.getCpf().getCpf() == null ||
            paciente.getCpf().getCpf().trim().isEmpty()) {
            return false;
        }
        return pacienteDAO.selectPacienteByCpf(paciente.getCpf().getCpf(), conexao) != null;
    }
}
