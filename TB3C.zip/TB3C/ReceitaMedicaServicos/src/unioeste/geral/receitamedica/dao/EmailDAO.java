package unioeste.geral.receitamedica.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import unioeste.geral.pessoa.bo.email.Email;

/**
 * DAO para manipular registros de Email associados a uma pessoa/paciente.
 */
public class EmailDAO {

    /**
     * Retorna a lista de emails de um paciente/pessoa, buscando pela FK 'id_pessoa'.
     * 
     * @param pessoaId  ID da pessoa/paciente no banco
     * @param conexao   Conexão JDBC aberta
     * @return          Lista de objetos Email
     * @throws Exception
     */
    public static List<Email> selectEmailsByPessoaId(Long pessoaId, Connection conexao) throws Exception {
        // Ajuste se o nome da tabela ou colunas forem diferentes
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT id_email, emails ");
        sql.append("FROM email ");
        sql.append("WHERE id_pessoa = ?;");

        PreparedStatement cmd = conexao.prepareStatement(sql.toString());
        cmd.setLong(1, pessoaId);

        ResultSet rs = cmd.executeQuery();
        List<Email> emailsLista = new ArrayList<>();

        while (rs.next()) {
            // Cria instância usando construtor padrão
            Email e = new Email();
            e.setId(rs.getLong("id_email"));      // 'id_email' no BD
            e.setEmails(rs.getString("emails"));  // 'emails' no BD

            // Se quiser, pode setar e.setNome(...), e.setEnderecoEspecifico(...), etc.
            // caso haja colunas extras na tabela 'email'.

            emailsLista.add(e);
        }

        return emailsLista;
    }

    /**
     * Insere um novo email para uma pessoa/paciente.
     * 
     * @param email     Objeto Email a ser inserido
     * @param pessoaId  ID da pessoa (ou paciente) associada
     * @param conexao   Conexão JDBC aberta
     * @throws Exception
     */
    public static void insertEmail(Email email, Long pessoaId, Connection conexao) throws Exception {
        // Ajuste se o nome da tabela ou colunas forem diferentes
        StringBuilder sql = new StringBuilder();
        sql.append("INSERT INTO email (emails, id_pessoa) VALUES (?, ?);");

        PreparedStatement cmd = conexao.prepareStatement(sql.toString());
        // 'emails' é o campo da classe que guarda o endereço de e-mail
        cmd.setString(1, email.getEmails());
        cmd.setLong(2, pessoaId);

        cmd.executeUpdate();
    }
}
