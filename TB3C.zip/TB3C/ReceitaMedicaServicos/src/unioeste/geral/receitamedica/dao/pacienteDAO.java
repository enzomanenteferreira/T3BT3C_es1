package unioeste.geral.receitamedica.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import unioeste.geral.endereco.bo.endereco.Endereco;
import unioeste.geral.endereco.dao.EnderecoDAO;
import unioeste.geral.endereco.bo.enderecoespecifico.EnderecoEspecifico;
import unioeste.geral.pessoa.bo.cpf.Cpf;
import unioeste.geral.pessoa.bo.email.Email;
import unioeste.geral.pessoa.bo.telefone.Telefone;
import unioeste.geral.receitaMedica.bo.paciente.Paciente;

public class pacienteDAO {

    /**
     * Busca um paciente pelo ID.
     */
    public static Paciente selectPacienteId(Long id, Connection conexao) throws Exception {
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT ");
        sql.append("  p.id_paciente, ");
        sql.append("  p.cpf, ");
        sql.append("  p.nome, ");
        sql.append("  p.primeiro_nome, ");
        sql.append("  p.nome_meio, ");
        sql.append("  p.ultimo_nome, ");
        sql.append("  p.id_endereco, ");
        sql.append("  p.complemento, ");
        sql.append("  p.numero_end ");
        sql.append("FROM paciente p ");
        sql.append("WHERE p.id_paciente = ?;");

        PreparedStatement cmd = conexao.prepareStatement(sql.toString());
        cmd.setLong(1, id);

        ResultSet rs = cmd.executeQuery();
        if (rs.next()) {
            // Carrega Endereco
            Endereco end = EnderecoDAO.selectEnderecoId(rs.getInt("id_endereco"), conexao);

            // Monta o objeto de end específico
            EnderecoEspecifico endEsp = new EnderecoEspecifico();
            endEsp.setEndereco(end);
            endEsp.setComplemento(rs.getString("complemento"));
            endEsp.setNumero(rs.getInt("numero_end"));

            /// Em vez de TelefonePacienteDAO, use TelefoneDAO
            List<Telefone> telefones = TelefoneDAO.selectTelefonesByPessoaId(id, conexao);

         // Em vez de EmailPacienteDAO, use EmailDAO
         List<Email> emails = EmailDAO.selectEmailsByPessoaId(id, conexao);


            // Cria CPF
            Cpf cpf = new Cpf(rs.getString("cpf"));

            // Monta o objeto Paciente
            Paciente pac = new Paciente();
            pac.setId(rs.getLong("id_paciente"));
            pac.setCpf(cpf);
            pac.setNome(rs.getString("nome"));
            pac.setPrimeiroNome(rs.getString("primeiro_nome"));
            pac.setNomeMeio(rs.getString("nome_meio"));
            pac.setUltimoNome(rs.getString("ultimo_nome"));
            pac.setEnderecoEspecifico(endEsp);
            pac.setTelefones(telefones);
            pac.setEmails(emails);

            return pac;
        }
        return null;
    }

    /**
     * Insere um novo paciente.
     * Exemplo usando SERIAL para id_paciente (neste caso, você pode usar RETURNING).
     */
    public static void insertPaciente(Paciente paciente, Connection conexao) throws Exception {
        StringBuilder sql = new StringBuilder();
        sql.append("INSERT INTO paciente ");
        sql.append("(cpf, nome, primeiro_nome, nome_meio, ultimo_nome, id_endereco, complemento, numero_end) ");
        sql.append("VALUES (?, ?, ?, ?, ?, ?, ?, ?) ");
        sql.append("RETURNING id_paciente;"); // se quiser recuperar o ID gerado

        PreparedStatement cmd = conexao.prepareStatement(sql.toString());
        cmd.setString(1, paciente.getCpf().getCpf());
        cmd.setString(2, paciente.getNome());
        cmd.setString(3, paciente.getPrimeiroNome());
        cmd.setString(4, paciente.getNomeMeio());
        cmd.setString(5, paciente.getUltimoNome());

        if (paciente.getEnderecoEspecifico() != null) {
            cmd.setInt(6, (int) paciente.getEnderecoEspecifico().getEndereco().getId());
            cmd.setString(7, paciente.getEnderecoEspecifico().getComplemento());
            cmd.setInt(8, paciente.getEnderecoEspecifico().getNumero());
        } else {
            cmd.setNull(6, java.sql.Types.INTEGER);
            cmd.setNull(7, java.sql.Types.VARCHAR);
            cmd.setNull(8, java.sql.Types.INTEGER);
        }

        ResultSet rs = cmd.executeQuery();
        if (rs.next()) {
            // Se precisar setar o ID que foi gerado
            long novoId = rs.getLong("id_paciente");
            paciente.setId(novoId);
        }
        rs.close();
        cmd.close();

        // Depois, se quiser inserir os telefones/emails
        // for (Telefone t : paciente.getTelefones()) {
        //     TelefonePacienteDAO.insertTelefone(t, paciente.getId(), conexao);
        // }
        // for (Email e : paciente.getEmails()) {
        //     EmailPacienteDAO.insertEmail(e, paciente.getId(), conexao);
        // }
    }

    /**
     * Exemplo: buscar paciente pelo CPF.
     */
    public static Paciente selectPacienteByCpf(String cpfValue, Connection conexao) throws Exception {
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT ");
        sql.append("  p.id_paciente, ");
        sql.append("  p.cpf, ");
        sql.append("  p.nome, ");
        sql.append("  p.primeiro_nome, ");
        sql.append("  p.nome_meio, ");
        sql.append("  p.ultimo_nome, ");
        sql.append("  p.id_endereco, ");
        sql.append("  p.complemento, ");
        sql.append("  p.numero_end ");
        sql.append("FROM paciente p ");
        sql.append("WHERE p.cpf = ?;");

        PreparedStatement cmd = conexao.prepareStatement(sql.toString());
        cmd.setString(1, cpfValue);
        ResultSet rs = cmd.executeQuery();

        if (rs.next()) {
            Long id = rs.getLong("id_paciente");
            Endereco end = EnderecoDAO.selectEnderecoId(rs.getInt("id_endereco"), conexao);
            EnderecoEspecifico endEsp = new EnderecoEspecifico();
            endEsp.setEndereco(end);
            endEsp.setComplemento(rs.getString("complemento"));
            endEsp.setNumero(rs.getInt("numero_end"));

         // Em vez de TelefonePacienteDAO, use TelefoneDAO
            List<Telefone> telefones = TelefoneDAO.selectTelefonesByPessoaId(id, conexao);

            // Em vez de EmailPacienteDAO, use EmailDAO
            List<Email> emails = EmailDAO.selectEmailsByPessoaId(id, conexao);

            Cpf cpf = new Cpf(rs.getString("cpf"));

            Paciente pac = new Paciente();
            pac.setId(id);
            pac.setCpf(cpf);
            pac.setNome(rs.getString("nome"));
            pac.setPrimeiroNome(rs.getString("primeiro_nome"));
            pac.setNomeMeio(rs.getString("nome_meio"));
            pac.setUltimoNome(rs.getString("ultimo_nome"));
            pac.setEnderecoEspecifico(endEsp);
            pac.setTelefones(telefones);
            pac.setEmails(emails);

            return pac;
        }
        return null;
    }
}
