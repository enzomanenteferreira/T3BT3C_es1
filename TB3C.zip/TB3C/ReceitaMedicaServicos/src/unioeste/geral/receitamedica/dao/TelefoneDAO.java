package unioeste.geral.receitamedica.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import unioeste.geral.pessoa.bo.telefone.Telefone;
import unioeste.geral.pessoa.bo.ddd.DDD;
import unioeste.geral.pessoa.bo.ddi.DDI;

/**
 * DAO para manipular registros de Telefone associados a uma pessoa/paciente.
 */
public class TelefoneDAO {

    /**
     * Retorna a lista de telefones de uma pessoa/paciente, filtrando por id_pessoa.
     *
     * @param pessoaId  ID da pessoa (ou paciente)
     * @param conexao   Conexão JDBC aberta
     * @return          Lista de objetos Telefone
     * @throws Exception
     */
    public static List<Telefone> selectTelefonesByPessoaId(Long pessoaId, Connection conexao) throws Exception {
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT id_telefone, numero, ddd, ddi ");
        sql.append("FROM telefone ");
        sql.append("WHERE id_pessoa = ?;");

        PreparedStatement cmd = conexao.prepareStatement(sql.toString());
        cmd.setLong(1, pessoaId);

        ResultSet rs = cmd.executeQuery();
        List<Telefone> telefones = new ArrayList<>();

        while (rs.next()) {
            // Lê os valores do ResultSet
            String numero = rs.getString("numero");
            // Lê o valor do ddd como inteiro e cria objeto DDD
            Integer numeroDDD = rs.getInt("ddd");
            DDD ddd = new DDD(numeroDDD);
            // Lê o valor do ddi como inteiro e cria objeto DDI
            Integer numeroDDI = rs.getInt("ddi");
            DDI ddi = new DDI(numeroDDI);

            // Cria o objeto Telefone utilizando o construtor completo
            Telefone telefone = new Telefone(numero, ddd, ddi);
            telefones.add(telefone);
        }

        return telefones;
    }
    
    /**
     * Insere um novo telefone para uma pessoa/paciente.
     *
     * @param telefone  Objeto Telefone a ser inserido
     * @param pessoaId  ID da pessoa (ou paciente) associada
     * @param conexao   Conexão JDBC aberta
     * @throws Exception
     */
    public static void insertTelefone(Telefone telefone, Long pessoaId, Connection conexao) throws Exception {
        StringBuilder sql = new StringBuilder();
        sql.append("INSERT INTO telefone (numero, ddd, ddi, id_pessoa) ");
        sql.append("VALUES (?, ?, ?, ?);");

        PreparedStatement cmd = conexao.prepareStatement(sql.toString());
        cmd.setString(1, telefone.getNumero());
        // Usa os getters de DDD e DDI para obter os números
        cmd.setInt(2, telefone.getDdd().getNumeroDDD());
        cmd.setInt(3, telefone.getDdi().getNumeroDDI());
        cmd.setLong(4, pessoaId);

        cmd.executeUpdate();
    }
}
