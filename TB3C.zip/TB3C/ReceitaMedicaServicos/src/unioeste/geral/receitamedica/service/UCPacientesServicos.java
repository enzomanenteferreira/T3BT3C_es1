package unioeste.geral.receitamedica.service;

import java.sql.Connection;

import unioeste.apoio.banco.ConexaoBanco;
import unioeste.geral.receitaMedica.bo.paciente.Paciente;
import unioeste.geral.receitamedica.col.pacienteCOL;
import unioeste.geral.receitamedica.dao.pacienteDAO;

/**
 * Classe de Caso de Uso para os serviços de Paciente.
 */
public class UCPacientesServicos {

    public UCPacientesServicos() {
    }

    /**
     * Cadastra um novo paciente após validação.
     * 
     * @param paciente Objeto Paciente a ser cadastrado.
     * @return O objeto Paciente cadastrado (com ID atribuído, se aplicável).
     * @throws ReceitaMedicaException Se o paciente for inválido ou já estiver cadastrado.
     * @throws Exception Se ocorrer algum erro na inserção.
     */
    public static Paciente cadastrarPaciente(Paciente paciente) throws Exception {
        ConexaoBanco conBanco = new ConexaoBanco();
        Connection conexao = conBanco.createConnection();
        try {
            // Valida os dados do paciente
            if (!pacienteCOL.pacienteValido(paciente)) {
                throw new ReceitaMedicaException("Paciente inválido");
            }
            // Verifica se o paciente já existe (por CPF)
            if (pacienteCOL.pacienteExiste(paciente, conexao)) {
                throw new ReceitaMedicaException("Paciente já cadastrado");
            }
            // Insere o paciente no banco
            pacienteDAO.insertPaciente(paciente, conexao);
            return paciente;
        } finally {
            conBanco.closeConnection(conexao);
        }
    }

    /**
     * Consulta um paciente pelo seu ID.
     * 
     * @param id ID do paciente a ser consultado.
     * @return Objeto Paciente encontrado.
     * @throws ReceitaMedicaException Se o ID for inválido ou o paciente não for encontrado.
     * @throws Exception Se ocorrer algum erro na consulta.
     */
    public static Paciente consultarPaciente(Long id) throws Exception {
        ConexaoBanco conBanco = new ConexaoBanco();
        Connection conexao = conBanco.createConnection();
        try {
            if (!pacienteCOL.idValido(id)) {
                throw new ReceitaMedicaException("ID do paciente inválido (" + id + ")");
            }
            Paciente paciente = pacienteDAO.selectPacienteId(id, conexao);
            if (paciente == null) {
                throw new ReceitaMedicaException("Paciente não cadastrado");
            }
            return paciente;
        } finally {
            conBanco.closeConnection(conexao);
        }
    }
}

/**
 * Exceção customizada para erros na lógica de Receita Médica.
 */
class ReceitaMedicaException extends Exception {
    public ReceitaMedicaException(String message) {
        super(message);
    }
}
