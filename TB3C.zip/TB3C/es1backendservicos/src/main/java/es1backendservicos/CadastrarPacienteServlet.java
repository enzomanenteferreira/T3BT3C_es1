package es1backendservicos;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;

import unioeste.geral.endereco.bo.endereco.Endereco;
import unioeste.geral.endereco.bo.enderecoespecifico.EnderecoEspecifico;
import unioeste.geral.pessoa.bo.cpf.Cpf;
import unioeste.geral.pessoa.bo.email.Email;
import unioeste.geral.pessoa.bo.telefone.Telefone;
import unioeste.geral.pessoa.bo.ddd.DDD;
import unioeste.geral.pessoa.bo.ddi.DDI;
import unioeste.geral.receitaMedica.bo.paciente.Paciente;
import unioeste.geral.receitamedica.service.UCPacientesServicos;

@WebServlet("/paciente/cadastrar")
public class CadastrarPacienteServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    public CadastrarPacienteServlet() {
        super();
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Para a resposta em JSON
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        
        JSONObject jsonResponse = new JSONObject();

        try {
            // === 1) Ler o corpo da requisição (JSON) ===
            StringBuilder sb = new StringBuilder();
            try (BufferedReader reader = request.getReader()) {
                String linha;
                while ((linha = reader.readLine()) != null) {
                    sb.append(linha);
                }
            }
            String body = sb.toString();

            // === 2) Converter para objeto JSON ===
            JSONObject jsonInput = new JSONObject(body);

            // === 3) Montar o objeto Paciente ===
            Paciente novoPaciente = new Paciente();

            // Nome
            if (jsonInput.has("nome")) {
                novoPaciente.setNome(jsonInput.getString("nome"));
            }

            // CPF
            if (jsonInput.has("cpf")) {
                Cpf cpf = new Cpf(jsonInput.getString("cpf"));
                novoPaciente.setCpf(cpf);
            }

            // Endereço Específico
            if (jsonInput.has("enderecoEspecifico")) {
                JSONObject jsonEndEsp = jsonInput.getJSONObject("enderecoEspecifico");
                EnderecoEspecifico endEsp = new EnderecoEspecifico();

                // id_endereco (FK)
                if (jsonEndEsp.has("idEndereco")) {
                    // Supondo que no BD já exista esse endereço cadastrado
                    Endereco end = new Endereco();
                    end.setId(jsonEndEsp.getInt("idEndereco"));
                    endEsp.setEndereco(end);
                }
                // Numero
                if (jsonEndEsp.has("numero")) {
                    endEsp.setNumero(jsonEndEsp.getInt("numero"));
                }
                // Complemento
                if (jsonEndEsp.has("complemento")) {
                    endEsp.setComplemento(jsonEndEsp.getString("complemento"));
                }
                novoPaciente.setEnderecoEspecifico(endEsp);
            }

            // Telefones
            if (jsonInput.has("telefones")) {
                JSONArray jsonTelefones = jsonInput.getJSONArray("telefones");
                ArrayList<Telefone> listaTelefones = new ArrayList<>();

                for (int i = 0; i < jsonTelefones.length(); i++) {
                    JSONObject jsonTel = jsonTelefones.getJSONObject(i);
                    String numero = jsonTel.getString("numero");
                    Integer dddValue = jsonTel.getInt("ddd");
                    Integer ddiValue = jsonTel.getInt("ddi");
                    
                    Telefone tel = new Telefone(numero, new DDD(dddValue), new DDI(ddiValue));
                    listaTelefones.add(tel);
                }
                novoPaciente.setTelefones(listaTelefones);
            }

            // Emails
            if (jsonInput.has("emails")) {
                JSONArray jsonEmails = jsonInput.getJSONArray("emails");
                ArrayList<Email> listaEmails = new ArrayList<>();

                for (int i = 0; i < jsonEmails.length(); i++) {
                    JSONObject jsonEmail = jsonEmails.getJSONObject(i);
                    Email e = new Email();
                    if (jsonEmail.has("email")) {
                        e.setEmails(jsonEmail.getString("email"));
                    }
                    listaEmails.add(e);
                }
                novoPaciente.setEmails(listaEmails);
            }

            // === 4) Chamar o serviço de cadastro ===
            Paciente pacienteCadastrado = UCPacientesServicos.cadastrarPaciente(novoPaciente);

            // === 5) Montar resposta JSON ===
            // OBS: Se o DAO não retorna o ID gerado, talvez fique null. Ajuste conforme necessário.
            jsonResponse.put("status", "sucesso");
            jsonResponse.put("idPaciente", pacienteCadastrado.getId() == null ? 0 : pacienteCadastrado.getId());
            jsonResponse.put("nomePaciente", pacienteCadastrado.getNome());

        } catch (Exception e) {
            // Em caso de erro, retorna JSON com mensagem de erro
            jsonResponse.put("status", "erro");
            jsonResponse.put("mensagem", e.getMessage());
            e.printStackTrace();
        }

        // === 6) Enviar resposta ===
        response.getWriter().write(jsonResponse.toString());
    }
}
