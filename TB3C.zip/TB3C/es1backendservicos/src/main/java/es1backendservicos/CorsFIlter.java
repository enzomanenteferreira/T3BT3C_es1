package es1backendservicos;


import java.io.IOException;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebFilter("/*") // Aplica este filtro a todas as requisições
public class CorsFIlter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // Se precisar de algo na inicialização do filtro
    }

    @Override
    public void doFilter(ServletRequest request, 
                         ServletResponse response, 
                         FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;

        // Define quais origens podem acessar (ex.: "*" para todas ou então "http://localhost:5500", etc.)
        res.setHeader("Access-Control-Allow-Origin", "*");
        // Quais métodos podem ser usados
        res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD");
        // Quais cabeçalhos podem ser enviados na requisição
        res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
        // Se for preciso permitir cookies/credentials, use:
        // res.setHeader("Access-Control-Allow-Credentials", "true");

        // Se for uma requisição do tipo OPTIONS (preflight), podemos retornar imediatamente
        if ("OPTIONS".equalsIgnoreCase(req.getMethod())) {
            res.setStatus(HttpServletResponse.SC_OK);
            return;
        }

        chain.doFilter(request, response);
    }

    @Override
    public void destroy() {
        // Se precisar limpar algo no destroy
    }
}
