package es1backendservicos;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import org.json.JSONArray;
import org.json.JSONObject;

import unioeste.geral.endereco.bo.endereco.Endereco;
import unioeste.geral.endereco.bo.enderecoespecifico.EnderecoEspecifico;
import unioeste.geral.pessoa.bo.email.Email;
import unioeste.geral.pessoa.bo.telefone.Telefone;
import unioeste.geral.receitaMedica.bo.paciente.Paciente;
import unioeste.geral.receitamedica.service.UCPacientesServicos;

@WebServlet("/paciente/consultar")
public class ConsultaPaciente extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public ConsultaPaciente() {
        super();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Configura o tipo de resposta para JSON
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        // Objeto de resposta JSON
        JSONObject jsonResponse = new JSONObject();

        try {
            // === 1) Ler o parâmetro "id" da query string ===
            String paramId = request.getParameter("id");
            if (paramId == null || paramId.trim().isEmpty()) {
                throw new Exception("Parâmetro 'id' não fornecido na URL. Ex: /paciente/consultar?id=1");
            }
            Long idPaciente = Long.parseLong(paramId);

            // === 2) Consultar o paciente via caso de uso ===
            Paciente paciente = UCPacientesServicos.consultarPaciente(idPaciente);

            // === 3) Montar JSON com os dados do paciente ===
            JSONObject jsonPaciente = new JSONObject();

            // ID do paciente (caso seu Paciente use Long, pode ser null; se for primitivo, não)
            Long id = paciente.getId();
            jsonPaciente.put("id", (id == null ? 0 : id));

            // Nome
            jsonPaciente.put("nome", (paciente.getNome() == null ? "" : paciente.getNome()));

            // CPF
            if (paciente.getCpf() != null) {
                jsonPaciente.put("cpf", paciente.getCpf().getCpf());
            } else {
                jsonPaciente.put("cpf", "");
            }

            // Montando o JSON de Endereço Específico
            JSONObject jsonEndEsp = new JSONObject();
            EnderecoEspecifico endEsp = paciente.getEnderecoEspecifico();
            if (endEsp != null) {
                // Numero
                if (endEsp.getNumero() != null) {
                    jsonEndEsp.put("numero", endEsp.getNumero());
                }
                // Complemento
                if (endEsp.getComplemento() != null) {
                    jsonEndEsp.put("complemento", endEsp.getComplemento());
                }
                // Endereco
                Endereco end = endEsp.getEndereco();
                if (end != null) {
                    // Aqui, id é do tipo int (conforme sua classe Endereco)
                    jsonEndEsp.put("idEndereco", end.getId());
                    // CEP
                    if (end.getCEP() != null) {
                        jsonEndEsp.put("cep", end.getCEP());
                    }
                    // Se quiser incluir mais detalhes, como cidade/bairro/logradouro:
                    //   - end.getCidade()
                    //   - end.getBairro()
                    //   - end.getLogradouro()
                }
            }
            jsonPaciente.put("enderecoEspecifico", jsonEndEsp);

            // Telefones
            JSONArray jsonTelefones = new JSONArray();
            if (paciente.getTelefones() != null) {
                for (Telefone tel : paciente.getTelefones()) {
                    JSONObject jsonTel = new JSONObject();
                    jsonTel.put("numero", tel.getNumero());
                    if (tel.getDdd() != null) {
                        jsonTel.put("ddd", tel.getDdd().getNumeroDDD());
                    }
                    if (tel.getDdi() != null) {
                        jsonTel.put("ddi", tel.getDdi().getNumeroDDI());
                    }
                    jsonTelefones.put(jsonTel);
                }
            }
            jsonPaciente.put("telefones", jsonTelefones);

            // Emails
            JSONArray jsonEmails = new JSONArray();
            if (paciente.getEmails() != null) {
                for (Email email : paciente.getEmails()) {
                    JSONObject jsonEmail = new JSONObject();
                    // Em sua classe Email, o campo do endereço é "emails" (String)
                    jsonEmail.put("email", (email.getEmails() == null ? "" : email.getEmails()));
                    jsonEmails.put(jsonEmail);
                }
            }
            jsonPaciente.put("emails", jsonEmails);

            // === 4) Retornar o JSON de sucesso ===
            jsonResponse.put("status", "sucesso");
            jsonResponse.put("paciente", jsonPaciente);

        } catch (Exception e) {
            // Em caso de erro, retorna JSON com mensagem de erro
            jsonResponse.put("status", "erro");
            jsonResponse.put("mensagem", e.getMessage());
            e.printStackTrace();
        }

        // === 5) Enviar resposta ===
        response.getWriter().write(jsonResponse.toString());
    }
}
