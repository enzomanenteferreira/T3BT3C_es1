package servicos_endereco_teste;

import java.util.Scanner;

import unioeste.geral.endereco.bo.bairro.Bairro;
import unioeste.geral.endereco.bo.cidade.Cidade;
import unioeste.geral.endereco.bo.endereco.Endereco;
import unioeste.geral.endereco.bo.logradouro.Logradouro;
import unioeste.geral.endereco.bo.tipologradouro.TipoLogradouro;
import unioeste.geral.endereco.bo.uf.Uf;

public class TesteUCEnderecoGeral {
	
	public static void print_cidade(Cidade cidade) {
		System.out.println("\nSigla Estado: " + cidade.getEstado().getSigla());
		System.out.println("Nome Estado: " + cidade.getEstado().getNome() );
		
        System.out.println("\nId Cidade: " + cidade.getId());
        System.out.println("Nome Cidade: " + cidade.getNome());
    }
	
	public static void print_endereco(Endereco endereco) {
        System.out.println("Id Endereço: " + endereco.getId());
        System.out.println("CEP: " + endereco.getCEP());
        
        print_cidade(endereco.getCidade());

        System.out.println("\nId Bairro: " + endereco.getBairro().getId());
        System.out.println("Nome Bairro: " + endereco.getBairro().getNome());
        
        System.out.println("\nId Logradouro: " + endereco.getLogradouro().getId());
        System.out.println("Nome Logradouro: " + endereco.getLogradouro().getNome());
        
        if(endereco.getLogradouro().getTipo_logradouro()==null) return;
        System.out.println("\nId Tipo Logradouro: " + endereco.getLogradouro().getTipo_logradouro().getId());
        System.out.println("Nome Tipo Logradouro: " + endereco.getLogradouro().getTipo_logradouro().getNome());
    }
	
	public static Endereco completar_endereco(Scanner scanner) {
		String CEP, nome_logradouro, nome_tipo_logradouro;
		int id_logradouro;
		System.out.print("CEP: ");
        CEP = scanner.nextLine();
        System.out.print("Id Logradouro: ");
        id_logradouro = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Nome Logradouro: ");
        nome_logradouro = scanner.nextLine();
        System.out.print("Nome Tipo Logradouro: ");
        nome_tipo_logradouro = scanner.nextLine();
		
		
		Endereco endereco = new Endereco();
		Uf estado = new Uf();
		estado.setSigla("PR");
		estado.setNome("Paraná");
		
		Cidade cidade = new Cidade();
		cidade.setId(1);
		cidade.setNome("Foz do Iguaçu");
		cidade.setEstado(estado);
		
		Bairro bairro = new Bairro();
		bairro.setId(1);
		bairro.setNome("Centro");
		
		TipoLogradouro tipo_logradouro = new TipoLogradouro();
		
		tipo_logradouro.setNome(nome_tipo_logradouro);
		if(nome_tipo_logradouro.equals("Alameda")) tipo_logradouro.setId(1);
		else if(nome_tipo_logradouro.equals("Avenida")) tipo_logradouro.setId(2);
		else if(nome_tipo_logradouro.equals("Beco")) tipo_logradouro.setId(3);
		else if(nome_tipo_logradouro.equals("Praça")) tipo_logradouro.setId(4);
		else if(nome_tipo_logradouro.equals("Rua")) tipo_logradouro.setId(5);
		else if(nome_tipo_logradouro.equals("Travessa")) tipo_logradouro.setId(6);
		else return null;
		
		Logradouro logradouro = new Logradouro();
		logradouro.setId(id_logradouro);
		logradouro.setNome(nome_logradouro);
		logradouro.setTipo_logradouro(tipo_logradouro);
		
		endereco.setCidade(cidade);
		endereco.setBairro(bairro);
		endereco.setLogradouro(logradouro);
		endereco.setId(1);
		endereco.setCEP(CEP);
		
		print_endereco(endereco);
		
		return endereco;
	}
	
	
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        Endereco obter_endereco_ex = new Endereco();
        Cidade obter_cidade_ex = new Cidade();

        
        String cep_ex = new String();
        
        int opcao;
        
        System.out.println("1. Cadastrar Endereço");
        System.out.println("2. Obter Endereço por CEP");
        System.out.println("3. Obter Endereço por ID");
        System.out.println("4. Obter Endereço Externo");
        System.out.println("5. Obter Cidade por Id");
        System.out.println("0. Sair");
        System.out.print("Escolha uma opção: ");
        opcao = scanner.nextInt();
        scanner.nextLine();

        switch (opcao) {
            case 1:
				try {
					Endereco endereco = completar_endereco(scanner);
					UCEnderecoGeralServicos.cadastrarEndereco(endereco);
				} catch (Exception e) {
					e.printStackTrace();
				}
                break;
            case 2:
				try {
					System.out.print("Insira o CEP: ");
			        String cep = scanner.nextLine();
					obter_endereco_ex = UCEnderecoGeralServicos.obterEnderecoPorCEP(cep);
					print_endereco(obter_endereco_ex);
				} catch (Exception e) {
					e.printStackTrace();
				}
                break;
            case 3:
				try {
					System.out.print("Insira o Id: ");
			        int id = scanner.nextInt();
			        scanner.nextLine();
					obter_endereco_ex = UCEnderecoGeralServicos.obterEnderecoPorID(id);
					print_endereco(obter_endereco_ex);
				} catch (Exception e) {
					e.printStackTrace();
				}
                break;
            case 4:
				try {
					System.out.print("Insira o CEP: ");
			        cep_ex = (scanner.nextLine());
					obter_endereco_ex = UCEnderecoGeralServicos.obterEnderecoExterno(cep_ex);
					print_endereco(obter_endereco_ex);
				} catch (Exception e) {
					e.printStackTrace();
				}
            	
                break;
            case 5:
                try {
                	System.out.print("Insira o Id: ");
			        int id = scanner.nextInt();
			        scanner.nextLine();
                	obter_cidade_ex = UCEnderecoGeralServicos.obterCidade(id);
                	print_cidade(obter_cidade_ex);
                }
                catch (Exception e) {
                	e.printStackTrace();
                }
            	
                
                break;
            case 0:
                System.out.println("Saindo do programa...");
                break;
            default:
                System.out.println("Opção inválida.");
                break;
        }
        
        scanner.close();
    }
}
