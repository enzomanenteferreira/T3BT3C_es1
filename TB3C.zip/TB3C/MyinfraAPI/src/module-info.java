/**
 * 
 */
/**
 * 
 */
module MyinfraAPI {
	requires java.sql;
	exports unioeste.apoio.banco;
}