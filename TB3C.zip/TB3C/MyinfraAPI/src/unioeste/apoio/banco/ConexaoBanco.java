package unioeste.apoio.banco;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexaoBanco {
    private static final String URL = "jdbc:postgresql://localhost:5432/es1"; //
    private static final String USER = "postgres"; 
    private static final String PASSWORD = "postgres"; 

    public ConexaoBanco() {
        try {
            Class.forName("org.postgresql.Driver"); 
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("Driver PostgreSQL não encontrado!", e);
        }
    }

    public Connection createConnection() {
        try {
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            System.err.println("Erro ao conectar ao banco de dados: " + e.getMessage());
            return null;
        }
    }

    public void closeConnection(Connection conn) {
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                System.err.println("Erro ao fechar conexão: " + e.getMessage());
            }
        }
    }
    public static void main(String[] args) {
        ConexaoBanco connectBD = new ConexaoBanco(); 
        Connection conn = connectBD.createConnection(); 
        if (conn != null) {
            System.out.println("Conexão com o banco PostgreSQL estabelecida com sucesso!");
            connectBD.closeConnection(conn);
        } else {
            System.out.println("Falha ao conectar ao banco de dados.");
        }
    }
}


