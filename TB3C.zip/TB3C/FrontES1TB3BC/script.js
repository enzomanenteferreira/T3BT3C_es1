// ====================================
// CONSTANTE COM A URL BASE DO SERVIDOR
// ====================================
const BASE_URL = "http://localhost:8080/es1backendservicos";

// ==========================
// Lógica de navegação de abas
// ==========================
document.querySelectorAll(".tab-button").forEach((button) => {
  button.addEventListener("click", () => {
    const tab = button.getAttribute("data-tab");

    // Ativa/Desativa botões
    document.querySelectorAll(".tab-button").forEach((btn) => {
      btn.classList.remove("active");
    });
    button.classList.add("active");

    // Mostra/Esconde conteúdos
    document.querySelectorAll(".tab-pane").forEach((pane) => {
      pane.classList.remove("active");
      if (pane.id === tab) {
        pane.classList.add("active");
      }
    });
  });
});

// ==========================
// 1) BUSCAR CIDADE POR ID
// ==========================
const formBuscarCidade = document.getElementById("formBuscarCidade");
const resultadoBuscaCidade = document.getElementById("resultadoBuscaCidade");

formBuscarCidade.addEventListener("submit", async (e) => {
  e.preventDefault();
  const cidadeId = document.getElementById("cidadeId").value.trim();

  try {
    const response = await fetch(`${BASE_URL}/obterCidade?id=${cidadeId}`);
    const data = await response.json();

    if (data.erro) {
      resultadoBuscaCidade.textContent = "Ocorreu um erro ao buscar a cidade.";
    } else {
      resultadoBuscaCidade.textContent = JSON.stringify(data, null, 2);
    }
  } catch (error) {
    resultadoBuscaCidade.textContent = "Erro na requisição!";
  }
});

// ==========================
// 2) BUSCAR ENDEREÇO POR ID
// ==========================
const formBuscarEnderecoId = document.getElementById("formBuscarEnderecoId");
const resultadoBuscaEnderecoId = document.getElementById("resultadoBuscaEnderecoId");

formBuscarEnderecoId.addEventListener("submit", async (e) => {
  e.preventDefault();
  const enderecoId = document.getElementById("enderecoId").value.trim();

  try {
    const response = await fetch(`${BASE_URL}/obterEnderecoID?id=${enderecoId}`);
    const data = await response.json();

    if (data.erro) {
      resultadoBuscaEnderecoId.textContent = "Ocorreu um erro ao buscar o endereço.";
    } else {
      resultadoBuscaEnderecoId.textContent = JSON.stringify(data, null, 2);
    }
  } catch (error) {
    resultadoBuscaEnderecoId.textContent = "Erro na requisição!";
  }
});

// ==========================
// 3) BUSCAR ENDEREÇO EXTERNO (POR CEP)
// ==========================
const formBuscarCepExterno = document.getElementById("formBuscarCepExterno");
const resultadoBuscaCepExterno = document.getElementById("resultadoBuscaCepExterno");

formBuscarCepExterno.addEventListener("submit", async (e) => {
  e.preventDefault();
  const cepExterno = document.getElementById("cepExterno").value.trim();

  try {
    const response = await fetch(`${BASE_URL}/obterCepExterno?cep=${cepExterno}`);
    const data = await response.json();

    if (data.erro) {
      resultadoBuscaCepExterno.textContent = "Ocorreu um erro ao buscar o endereço externo.";
    } else {
      resultadoBuscaCepExterno.textContent = JSON.stringify(data, null, 2);
    }
  } catch (error) {
    resultadoBuscaCepExterno.textContent = "Erro na requisição!";
  }
});

// ==========================
// 4) CADASTRAR NOVO ENDEREÇO
// ==========================
const formCadastrarEndereco = document.getElementById("formCadastrarEndereco");
const resultadoCadastroEndereco = document.getElementById("resultadoCadastroEndereco");

formCadastrarEndereco.addEventListener("submit", async (e) => {
  e.preventDefault();

  // Coletando os campos que o usuário insere:
  const id_logradouro = document.getElementById("id_logradouro").value.trim();
  const id_cidade = document.getElementById("id_cidade").value.trim();
  const id_bairro = document.getElementById("id_bairro").value.trim();
  const cep = document.getElementById("cep").value.trim();

  // Coletando os campos "ocultos" (ou fixos):
  const sigla_estado = document.getElementById("sigla_estado").value.trim();
  const nome_estado = document.getElementById("nome_estado").value.trim();
  const nome_cidade = document.getElementById("nome_cidade").value.trim();
  const nome_bairro = document.getElementById("nome_bairro").value.trim();
  const nome_logradouro = document.getElementById("nome_logradouro").value.trim();
  const id_tipo_logradouro = document.getElementById("id_tipo_logradouro").value.trim();
  const nome_tipo_logradouro = document.getElementById("nome_tipo_logradouro").value.trim();

  // Monta os parâmetros que serão enviados via POST
  const formData = new URLSearchParams();
  formData.append("sigla_estado", sigla_estado);
  formData.append("nome_estado", nome_estado);
  formData.append("id_cidade", id_cidade);
  formData.append("nome_cidade", nome_cidade);
  formData.append("id_bairro", id_bairro);
  formData.append("nome_bairro", nome_bairro);
  formData.append("id_logradouro", id_logradouro);
  formData.append("nome_logradouro", nome_logradouro);
  formData.append("id_tipo_logradouro", id_tipo_logradouro);
  formData.append("nome_tipo_logradouro", nome_tipo_logradouro);
  formData.append("cep", cep);

  try {
    const response = await fetch(`${BASE_URL}/cadastrarEndereco`, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
      },
      body: formData.toString(),
    });

    const data = await response.json();

    if (data.inserido) {
      resultadoCadastroEndereco.textContent = "Endereço cadastrado com sucesso!";
    } else if (data.erro) {
      resultadoCadastroEndereco.textContent = "Ocorreu um erro ao cadastrar o endereço. Verifique se as referências existem no BD.";
    } else {
      resultadoCadastroEndereco.textContent = "Erro ao cadastrar o endereço (retorno inesperado).";
    }
  } catch (error) {
    resultadoCadastroEndereco.textContent = "Erro na requisição!";
  }
});

// ==========================
// EXEMPLO: Cadastro Paciente
// ==========================
const formCadastroPaciente = document.getElementById("formCadastroPaciente");
formCadastroPaciente.addEventListener("submit", (e) => {
  e.preventDefault();
  // Exemplo fictício (lógica real ficaria aqui):
  alert("Paciente cadastrado (exemplo).");
});

const btnPesquisarPaciente = document.getElementById("btnPesquisarPaciente");
btnPesquisarPaciente.addEventListener("click", () => {
  const pesquisa = document.getElementById("pesquisaPaciente").value;
  alert(`Pesquisa de paciente por: ${pesquisa}`);
});
